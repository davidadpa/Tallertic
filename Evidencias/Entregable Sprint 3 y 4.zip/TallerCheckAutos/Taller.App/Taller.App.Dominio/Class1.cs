﻿namespace Taller.App.Dominio;
public class Class1
{

}

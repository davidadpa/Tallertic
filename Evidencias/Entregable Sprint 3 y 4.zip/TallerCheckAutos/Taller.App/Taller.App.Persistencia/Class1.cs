﻿namespace Taller.App.Persistencia;
public class Class1
{

}

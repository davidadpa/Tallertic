using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Taller.App.Front.Pages
{
    public class dataMecanico
    {
        public int Id {get; set;}
        public string Nombre {get; set;}
        public string Telefono {get; set;}
        public string Contrasena {get; set;}
        public string Rol {get; set;}
        public string NivelEstudio {get; set;}
        public string Sede {get; set;}
    }
}
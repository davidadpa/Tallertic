using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller.App.Front.Pages
{
    public class GestionNotificacionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

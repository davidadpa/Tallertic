using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller.App.Front.Pages
{
    public class GestionJefeOperacionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
